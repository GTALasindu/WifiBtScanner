# Wi-Fi & Bluetooth Scanner (Android / Kotlin + Jetpack Compose)

A simple Android app with two tabs:

1. **Wi-Fi tab** — scans and lists nearby Wi-Fi networks (SSID, signal
   strength in dBm, security type). This uses the public broadcast
   information every device sends out; it does **not** and cannot reveal
   Wi-Fi passwords. To actually join a network, the real password still has
   to be entered (the standard Android connect flow / Settings).

2. **Bluetooth tab** — lists devices already **paired** with your phone, and
   can also discover nearby unpaired devices. Connecting is implemented for
   devices in your paired list (safe — your phone already trusts them) using
   the standard Serial Port Profile (SPP) UUID. Connecting to an unpaired
   device will trigger Android's normal pairing confirmation dialog — this
   app does not bypass that.

## How to run it

1. Install [Android Studio](https://developer.android.com/studio).
2. Open this folder (`WifiBtScanner/`) as a project.
3. Let Gradle sync (it will download dependencies — needs internet).
4. Connect a physical Android phone (with USB debugging enabled) or start an
   emulator. Note: Wi-Fi scanning doesn't work well on emulators — a real
   device is recommended for the Wi-Fi tab.
5. Click Run ▶.
6. On first launch, grant the location and Bluetooth permissions when
   prompted (Android requires location permission for Wi-Fi/Bluetooth
   scanning APIs — the app doesn't use it for anything else).

## Project structure

```
WifiBtScanner/
  app/
    src/main/
      AndroidManifest.xml
      java/com/example/wifibtscanner/
        MainActivity.kt      — UI (Compose), permission handling
        WifiScanner.kt       — Wi-Fi scan logic
        BluetoothHelper.kt   — Bluetooth discovery + connect logic
  build.gradle.kts / settings.gradle.kts — Gradle config
```

## Scope notes

This app intentionally does **not** include any password-cracking, packet
injection, or silent/unauthorized pairing functionality — those would be
illegal to use against networks or devices you don't own or have permission
to access. Everything here works within normal Android permission and
pairing flows.
