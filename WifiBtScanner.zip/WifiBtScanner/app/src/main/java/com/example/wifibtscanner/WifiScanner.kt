package com.example.wifibtscanner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import androidx.compose.runtime.mutableStateListOf

/**
 * Scans for nearby Wi-Fi networks (SSID, signal strength, security type).
 * This only reads publicly broadcast network info — it cannot and does not
 * reveal Wi-Fi passwords. To connect, the real password must be entered
 * by the user (handled by the OS connect dialog).
 */
data class WifiNetwork(
    val ssid: String,
    val bssid: String,
    val levelDbm: Int,
    val capabilities: String
)

class WifiScanner(private val context: Context) {

    val results = mutableStateListOf<WifiNetwork>()

    private val wifiManager: WifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            val success = intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false)
            if (success) {
                updateResults()
            }
        }
    }

    fun register() {
        val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        context.applicationContext.registerReceiver(receiver, filter)
    }

    fun unregister() {
        try {
            context.applicationContext.unregisterReceiver(receiver)
        } catch (_: IllegalArgumentException) {
            // receiver was already unregistered
        }
    }

    /** Kick off a scan. Requires ACCESS_FINE_LOCATION + ACCESS_WIFI_STATE granted. */
    fun startScan(): Boolean {
        val started = wifiManager.startScan()
        if (!started) {
            // Some OEMs throttle scans; fall back to showing the last known results.
            updateResults()
        }
        return started
    }

    private fun updateResults() {
        val scanResults = wifiManager.scanResults
        results.clear()
        results.addAll(
            scanResults
                .map {
                    WifiNetwork(
                        ssid = if (it.SSID.isNullOrBlank()) "(hidden network)" else it.SSID,
                        bssid = it.BSSID ?: "",
                        levelDbm = it.level,
                        capabilities = it.capabilities ?: ""
                    )
                }
                .sortedByDescending { it.levelDbm }
        )
    }
}
