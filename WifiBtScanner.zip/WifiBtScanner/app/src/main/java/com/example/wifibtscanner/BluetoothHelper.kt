package com.example.wifibtscanner

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.compose.runtime.mutableStateListOf
import java.io.IOException
import java.util.UUID

/**
 * Discovers nearby Bluetooth devices and lets you open a connection to a
 * device that is already paired/bonded with this phone (e.g. your own
 * headphones, a BLE board you own, etc). It will NOT silently pair with or
 * connect to someone else's device without the normal Android pairing
 * confirmation.
 */
data class BtDevice(
    val name: String,
    val address: String,
    val bonded: Boolean,
    val rssi: Int? = null // signal strength in dBm; closer to 0 = stronger/closer
)

// Standard Serial Port Profile UUID — works for most classic-Bluetooth
// "connect and talk" use cases (e.g. HC-05/HC-06 modules, many headsets).
private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

class BluetoothHelper(private val context: Context) {

    val discovered = mutableStateListOf<BtDevice>()
    val pairedDevices = mutableStateListOf<BtDevice>()
    var statusMessage: String = ""
        private set

    private val adapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var socket: BluetoothSocket? = null

    private val receiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? =
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    device ?: return
                    val rssi = intent.getShortExtra(
                        BluetoothDevice.EXTRA_RSSI,
                        Short.MIN_VALUE
                    ).let { if (it == Short.MIN_VALUE) null else it.toInt() }

                    val entry = BtDevice(
                        name = device.name ?: "(unknown device)",
                        address = device.address,
                        bonded = device.bondState == BluetoothDevice.BOND_BONDED,
                        rssi = rssi
                    )
                    val existingIndex = discovered.indexOfFirst { it.address == entry.address }
                    if (existingIndex >= 0) {
                        // Update signal strength in place so the UI shows live
                        // "warmer/colder" movement as the device gets closer or farther.
                        discovered[existingIndex] = entry
                    } else {
                        discovered.add(entry)
                    }
                }
            }
        }
    }

    /** When true, discovery auto-restarts when it finishes, so RSSI keeps updating live. */
    var liveTracking: Boolean = false

    private val discoveryFinishedReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == BluetoothAdapter.ACTION_DISCOVERY_FINISHED && liveTracking) {
                adapter?.startDiscovery()
            }
        }
    }

    fun register() {
        context.applicationContext.registerReceiver(
            receiver,
            IntentFilter(BluetoothDevice.ACTION_FOUND)
        )
        context.applicationContext.registerReceiver(
            discoveryFinishedReceiver,
            IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        )
    }

    fun unregister() {
        liveTracking = false
        try {
            context.applicationContext.unregisterReceiver(receiver)
        } catch (_: IllegalArgumentException) {
        }
        try {
            context.applicationContext.unregisterReceiver(discoveryFinishedReceiver)
        } catch (_: IllegalArgumentException) {
        }
    }

    fun isEnabled(): Boolean = adapter?.isEnabled == true

    /** Already paired devices — the safe, normal set of devices you can connect to. */
    @SuppressLint("MissingPermission")
    fun loadPairedDevices() {
        pairedDevices.clear()
        val bonded = adapter?.bondedDevices ?: emptySet()
        pairedDevices.addAll(
            bonded.map {
                BtDevice(name = it.name ?: "(unknown)", address = it.address, bonded = true)
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun startDiscovery(): Boolean {
        discovered.clear()
        if (adapter?.isDiscovering == true) adapter.cancelDiscovery()
        return adapter?.startDiscovery() ?: false
    }

    @SuppressLint("MissingPermission")
    fun cancelDiscovery() {
        if (adapter?.isDiscovering == true) adapter.cancelDiscovery()
    }

    /**
     * Opens an RFCOMM connection to a device by MAC address.
     * Works reliably for devices that are already paired/bonded with this
     * phone. For an unpaired device, Android will prompt the normal system
     * pairing dialog first.
     */
    @SuppressLint("MissingPermission")
    fun connectTo(address: String, onResult: (success: Boolean, message: String) -> Unit) {
        val device = adapter?.getRemoteDevice(address)
        if (device == null) {
            onResult(false, "Device not found")
            return
        }
        Thread {
            try {
                cancelDiscovery() // discovery slows down connections
                val s = device.createRfcommSocketToServiceRecord(SPP_UUID)
                socket = s
                s.connect()
                onResult(true, "Connected to ${device.name ?: address}")
            } catch (e: IOException) {
                onResult(false, "Connection failed: ${e.message}")
            }
        }.start()
    }

    fun disconnect() {
        try {
            socket?.close()
        } catch (_: IOException) {
        }
        socket = null
    }
}
