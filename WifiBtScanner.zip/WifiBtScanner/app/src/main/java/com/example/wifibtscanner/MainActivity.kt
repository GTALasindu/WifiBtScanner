package com.example.wifibtscanner

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var wifiScanner: WifiScanner
    private lateinit var btHelper: BluetoothHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifiScanner = WifiScanner(this)
        btHelper = BluetoothHelper(this)

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot(wifiScanner, btHelper)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        wifiScanner.register()
        btHelper.register()
    }

    override fun onStop() {
        super.onStop()
        wifiScanner.unregister()
        btHelper.unregister()
    }
}

private fun requiredPermissions(): Array<String> {
    val perms = mutableListOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_WIFI_STATE,
        Manifest.permission.CHANGE_WIFI_STATE
    )
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        perms.add(Manifest.permission.BLUETOOTH_SCAN)
        perms.add(Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        perms.add(Manifest.permission.BLUETOOTH)
        perms.add(Manifest.permission.BLUETOOTH_ADMIN)
    }
    return perms.toTypedArray()
}

@Composable
fun AppRoot(wifiScanner: WifiScanner, btHelper: BluetoothHelper) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var hasPermissions by remember {
        mutableStateOf(
            requiredPermissions().all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        hasPermissions = results.values.all { it }
    }

    val enableBtLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { /* result ignored; user can retry scan */ }

    var selectedTab by remember { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Wi-Fi") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Bluetooth") })
        }

        if (!hasPermissions) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("This app needs location and Bluetooth permissions to scan for nearby Wi-Fi and Bluetooth devices.")
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = { permissionLauncher.launch(requiredPermissions()) }) {
                    Text("Grant permissions")
                }
            }
        } else {
            when (selectedTab) {
                0 -> WifiTab(wifiScanner)
                1 -> BluetoothTab(btHelper, onRequestEnableBt = {
                    val enableIntent = android.content.Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                    enableBtLauncher.launch(enableIntent)
                })
            }
        }
    }
}

@Composable
fun WifiTab(scanner: WifiScanner) {
    var scanning by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Button(
            onClick = {
                scanning = true
                scanner.startScan()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (scanning) "Scanning..." else "Scan for Wi-Fi networks")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("Found ${scanner.results.size} network(s). Tap the gear icon in Android settings to connect — this app only displays what's broadcast publicly; it cannot reveal passwords.")
        Spacer(modifier = Modifier.height(8.dp))
        LazyColumn {
            items(scanner.results) { net ->
                ElevatedCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(net.ssid, style = MaterialTheme.typography.titleMedium)
                        Text("BSSID: ${net.bssid}", style = MaterialTheme.typography.bodySmall)
                        Text("Signal: ${net.levelDbm} dBm", style = MaterialTheme.typography.bodySmall)
                        Text("Security: ${net.capabilities}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun BluetoothTab(helper: BluetoothHelper, onRequestEnableBt: () -> Unit) {
    var statusText by remember { mutableStateOf("") }
    var showPairedOnly by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        helper.loadPairedDevices()
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        if (!helper.isEnabled()) {
            Text("Bluetooth is off.")
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = onRequestEnableBt) { Text("Enable Bluetooth") }
            Spacer(modifier = Modifier.height(16.dp))
        }

        var liveTracking by remember { mutableStateOf(false) }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {
                helper.loadPairedDevices()
                helper.startDiscovery()
            }) {
                Text("Scan for devices")
            }
            Spacer(modifier = Modifier.width(12.dp))
            TextButton(onClick = { showPairedOnly = !showPairedOnly }) {
                Text(if (showPairedOnly) "Paired only" else "All found")
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(
                checked = liveTracking,
                onCheckedChange = {
                    liveTracking = it
                    helper.liveTracking = it
                    if (it) helper.startDiscovery()
                }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Live signal tracking (walk around to find closest device)")
        }

        Spacer(modifier = Modifier.height(8.dp))
        if (statusText.isNotBlank()) {
            Text(statusText, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(8.dp))
        }

        val list = if (showPairedOnly) helper.pairedDevices else helper.discovered

        Text(
            if (showPairedOnly)
                "Paired devices — connecting here is safe since these are already trusted by your phone."
            else
                "All nearby devices. You can only connect to ones you've paired with (or will go through the normal Android pairing prompt)."
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn {
            items(list) { dev ->
                ElevatedCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(dev.name, style = MaterialTheme.typography.titleMedium)
                        Text(dev.address, style = MaterialTheme.typography.bodySmall)
                        Text(
                            if (dev.bonded) "Paired" else "Not paired",
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (dev.rssi != null) {
                            val proximity = when {
                                dev.rssi > -50 -> "Very close (hot)"
                                dev.rssi > -70 -> "Nearby (warm)"
                                dev.rssi > -85 -> "Far (cool)"
                                else -> "Very far (cold)"
                            }
                            Text(
                                "Signal: ${dev.rssi} dBm — $proximity",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(onClick = {
                            statusText = "Connecting..."
                            helper.connectTo(dev.address) { success, message ->
                                statusText = message
                            }
                        }) {
                            Text("Connect")
                        }
                    }
                }
            }
        }
    }
}
